Point Cloud Library (PCL) public roadmap
----------------------------------------


